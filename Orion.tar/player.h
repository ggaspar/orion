#include "tabel.h"
#include <string>
#include "cardSet.h"

#ifndef __PLAYER_H__
#define __PLAYER_H__



class Player
{
	friend class Game;
 public:
  Player(string name) : _name(name) {};
  Tabel* _currentTabelState;
  Card play(Tabel& tabel, int invalidErrorMessage)
  {
	_currentTabelState = &tabel;
	Card* c = &playCard(invalidErrorMessage);
	return (*c);
  };	  
  
  virtual Card playCard(int invalidErrorMessage) = 0;

  Card getCard(int index)
  {
    return _cards[index];
  };

  int getNumberCards()
  {
    return _cards.size();
  };

  bool hasCards(){ return _cards.size()>0; };
  void showCards() { cout << _cards; cout << endl; };
  const CardSet& getCards() const
  {
    return (const CardSet&)_cards;
  };
  void addOtherPlayerDeck(CardSet* cards)
  {
	  otherPlayerCards=cards;
  };
  CardSet* otherPlayerCards;
  string getName()
  {
	return _name;
  };
 private : 
  void receiveCard(const Card& c)
  {
   _cards.pushCard(c);  
  };
  CardSet _cards;
  string _name;
  PlayerId _id;




  
  

};

#endif
