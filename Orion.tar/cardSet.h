﻿#include "card.h"
#include <vector>
#include <algorithm>


#ifndef __CARD_SET_H__
#define __CARD_SET_H__

class CardSet
{
 public :
  bool hasSuit(const CardSuit cs) const
  {
    vector<Card>::const_iterator csit;
    for ( csit = cards.begin(); csit!=cards.end(); ++csit)
    {
     if(cs==(*csit)._suit)
     {
      return true;
     }
    }
   return false;
  };
  void createDeck()
  {
    //char suits[4] = { 0x03, 0x04, 0x05, 0x06 }; 
	char suits[4] = { 'D', 'C', 'S', 'H' }; 
    char faces[13] = {'2','3','4','5','6','7','8','9','T','J','Q','R','A'};
    int ranks[13] = {2,3,4,5,6,7,8,9,10,11,12,13,14};

    int isuits, ifaces, iranks;
    for( isuits = 0; isuits != 4; ++isuits)
    {
     for( ifaces = 0, iranks = 0; ifaces != 13; ++ifaces, ++iranks)
     {
      Card c(faces[ifaces],suits[isuits],ranks[iranks]);
      pushCard(c);
     }

    }
  };
  int size() { return cards.size(); };
  void pushCard(const Card& c)
  {
    cards.push_back(c);
  };
  Card chooseCard(int i)
  {
   return cards[i];
  };
  void removeCard(Card card)
  {
   cards.erase(remove(cards.begin(), cards.end(), card), cards.end());
  };
  Card popCard()
  {
   Card card = chooseCard(cards.size()-1);
   removeCard(card);
   return card;
  }; 
  friend ostream& operator<<(ostream &out, const CardSet& cs )
  {
    vector<Card>::const_iterator csit;
    int i =1;
    for ( csit = cs.cards.begin(); csit!=cs.cards.end(); ++csit, ++i)
    {
      out << i << ": " << *csit << endl;
    }
	return out;
  };
  void shuffle()
  {
   random_shuffle(cards.begin(), cards.end(), myrandom);
  };
  Card operator[](int index)
  {
    return cards[index];
  };
 private :
  vector<Card> cards;
};

#endif