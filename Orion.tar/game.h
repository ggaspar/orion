#include "playerDerp.h"
#include "playerHuman.h"
#include "rules.h"
#include <map>

#ifndef __GAME_H__
#define __GAME_H__

class Game
{
 public :
	 Game()
  {
	cards.createDeck();
	cards.shuffle();
	cout << cards;
	int cardNumber=10;
	_tabel = new Tabel();
	_rules = new Rules(2);
	
	Player* player = new PlayerHuman("Human");
	PlayerId id = _tabel->addPlayer(player->_name);
	_players[id] = player;
	player = new PlayerDerp("Derp");
	id = _tabel->addPlayer(player->_name);
	_players[id] = player;
	

	for (int i = 0; i < cardNumber; ++i)
	{
		map<PlayerId, Player*>::iterator playersIt = _players.begin();
		for( ; playersIt != _players.end(); ++playersIt)
		{
			(*playersIt).second->receiveCard(cards.popCard());
		}
	}
  };
  
  void start()
  {
	
	//_player1.addOtherPlayerDeck(&_player2._cards);	
	while ((*_players.begin()).second->hasCards())
	{
		Card *card;
		PlayerId currentId = _tabel->getFirstToPlay();
		
		do
		{
			int stateValue = 1;
			Player* currentPlayer = _players[currentId];
			card = &currentPlayer->play(*_tabel,FIRST_MOVE);
			_tabel->attemptNewMasterSuit(card);
	
			//cout << "hello: " << (stateValue = _rules->isStateValid(*_tabel, (*currentPlayer), (*card))) != 0;
			while((stateValue = _rules->isStateValid(*_tabel, (*currentPlayer), (*card))) != VALID_MOVE)
			{
				//gs.removeMasterCard();
				card = &currentPlayer->play(*_tabel, stateValue);
			}
			(*currentPlayer)._cards.removeCard(*card);
			_tabel->addCardToCurrentPlayer(card);
			cout << "player " << currentPlayer->_name  << " plays " << (*card);
			cout << endl;
		
		}while((currentId = _tabel->getNextPlayer()) != -1);
	
		PlayerId winnerId = _rules->getRoundWinner(_tabel);
		if(winnerId == -1)
		{
			//draw
			cout << "there was a draw" << endl;
		}
		else
		{
			_tabel->addPoint(winnerId);
			_tabel->newRound(winnerId);
			cout << "player "<< _players[winnerId]->_name <<" wins this round." << endl;
			_tabel->showScore();
		}		
	}

	PlayerId winner = _rules->getGameWinner(_tabel);

	if(winner==-1)
	{
		cout << "It was a draw!" << endl;
	}
	else
	{
		cout << "Player " << _players[winner]->_name << " WON the GAME!!!" << endl;
	}
	
	_tabel->showScore();


	/*if (_player1._points > _player2._points)
	{
	cout << "player 1 wins with " <<  _player1._points << " points" <<  endl;
	}
	else if (_player1._points < _player2._points)
	{
	cout << "player 2 wins with " <<  _player2._points << " points" << endl;
	}
	else
	{
	cout << "It was a draw! Both Players have " <<  _player2._points << " points" << endl;
	};*/
  };

 private :

  map<PlayerId,Player*> _players;
  CardSet cards;
  Rules* _rules;

  Tabel* _tabel;
};

#endif