#include "game.h"
#include <iostream>
#include <string>

using namespace std;

class Animal
{        
    public: 
      // turn the following virtual modifier on/off to see what happens
      //virtual   
      std::string Says() { return "?"; }  
};

class Dog: public Animal
{
    public: std::string Says() { return "Woof"; }
};

void test()
{
    Dog* d = new Dog();
    Animal* a = d;       // refer to Dog instance with Animal pointer

    cout << d->Says();   // always Woof
    cout << a->Says();   // Woof or ?, depends on virtual
}


int main()
{
 char eog;
 Game game;
 //test();
 game.start();
 
 cin >> eog;
 return 0;
}

