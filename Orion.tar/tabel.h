#include <string>
#include <vector>
#include "resources.h"
#include "card.h"

//lame attempt to define a foreach.. to be reviewed later
//define foreachPlayer(index) for(index=0 ; index != _players.size(); ++index);


#ifndef __TABEL_H__
#define __TABEL_H__

using namespace std;
class Tabel
{
	friend class Rules;
	class PlayerStatus
	{	
	public :
		PlayerStatus(PlayerId id, string name) : _points(0), _name(name), _played(false), 
												_isFirst(false), _card(NULL), _playerId(id) {};
		//Player *_player;
		bool _played;
		bool _isFirst;
		Card *_card;
		PlayerId _playerId;
		string _name;
		int _points;
	};

public :
	Tabel() : _currentIndex(0), _current(NULL), _players(0){};

	PlayerId addPlayer(string _name)
	{
		PlayerId id = _players.empty() ? 0 : _players.size();
		_players.push_back(new PlayerStatus(id, _name));
		return id;
	};


	PlayerId getFirstToPlay()
	{
		//to randomly choose a player, if there's no defined first player
		int i = myrandom(_players.size());
		bool firstFound=false;
		for(int pIndex = 0;	pIndex < _players.size(); ++pIndex)
		{ 
			if (_players[pIndex]->_isFirst)
			{
				i = pIndex;
				//break doesn't work because of MACRO.. shouldn't have any functional impact
				//break;
			};
		}
		if(!firstFound) _players[i]->_isFirst=true;
		_currentIndex = i;
		_current = _players[i];
		return _current->_playerId;

	}
	PlayerId getNextPlayer()
	{
		_current->_played=true;
		++_currentIndex;
		if(_players.size() <= _currentIndex)
		{
		 _currentIndex=0;
		}
		_current = _players[_currentIndex];
		if(_current->_played)
		{
			_current=NULL;
			return -1;
		}

		return _current->_playerId;	
	}

	void newRound(PlayerId winner)
	{		
		for(int pIndex = 0;	pIndex < _players.size(); ++pIndex)
		{ 
			_players[pIndex]->_played=false;		
			_players[pIndex]->_isFirst = (winner==_players[pIndex]->_playerId);
		}
		
	}

	void addCardToCurrentPlayer(Card* card)
	{
		_current->_card=card;		
	}

	void attemptNewMasterSuit(Card* card)
	{
		if(_current->_isFirst) _masterSuit = card->_suit;
	}

	void addPoint(PlayerId id)
	{
		_players[id]->_points++;
	}

	void showScore()
	{
		cout << "Score Table:" << endl;
		for(int pIndex = 0;	pIndex < _players.size(); ++pIndex)
		{
			cout << _players[pIndex]->_name << ": " << (int)_players[pIndex]->_points << endl;
		}
			
	}

	PlayerStatus *_current;
	int _currentIndex;
	vector<PlayerStatus*> _players;
	CardSuit _masterSuit;
	

};

#endif