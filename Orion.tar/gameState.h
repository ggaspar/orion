#include "cardSet.h"

#ifndef __GAME_STATE_H__
#define __GAME_STATE_H__

class GameState
{

 public :
  GameState()
  {
	_masterCard = NULL;
	_followCard = NULL;
	_followSuit = NULL;
	_masterSuit = NULL;
	_nextGS = NULL;
	_previousGS = NULL;
	_firstGS=this;
  };
  GameState& newGameState()
  {
	GameState* gs = new GameState();
	gs->_previousGS=this;
	_nextGS=gs;
	gs->_firstGS=_firstGS;
	return *gs;
  };
  void addMasterCard(Card* c)
  {
	  _masterCard = c;
	  _masterSuit = &(*c)._suit;
  };
  void removeMasterCard()
  {	
	  _masterSuit = NULL;
  };
  void addFollowCard(Card* c)
  {
	  _followCard = c;
	  _followSuit = &(*c)._suit;
  };
  void removeFollowCard()
  {	
	  _followCard = NULL;
  };

  Card *_masterCard, *_followCard;
  CardSuit *_masterSuit, *_followSuit;
  GameState *_nextGS, *_previousGS, *_firstGS;
 

};

#endif
