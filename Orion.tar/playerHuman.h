#include "player.h"

#ifndef __PLAYER_HUMAN_H__
#define __PLAYER_HUMAN_H__
using namespace std;

class PlayerHuman : public Player
{
 public:
  PlayerHuman(string name) : Player(name) {};
  Card playCard(int invalidErrorMessage)
  { 

	string sPlay;   
	if(invalidErrorMessage == SUIT_NOT_FOLLOWING_MASTER)
	{
		cout << "Invalid move! You must follow the suit played!" << endl;
	}
	cout << "which card you want to play?" << endl;
    showCards();
	cin >> sPlay;
	if(sPlay=="c") 
	{
		seeOtherPlayerCards();
	}
	int iPlay = StringToNumber<int>(sPlay);
	while (iPlay < 1 || iPlay > getNumberCards()) 
	{
		if(getNumberCards() == 1)
		{
			cout << "Card/Command not recognized. Card 1, your last card, will be played." <<endl;	
			iPlay = 1;
		}
		else
		{
			cout << "Card/Command not recognized. Please type a number between 1 and " << getNumberCards() << endl;
			cin >> sPlay;
			iPlay = StringToNumber<int>(sPlay);
		}

	}

	return getCard(iPlay - 1);
  };
  void seeOtherPlayerCards()
  {
	  cout << (*otherPlayerCards); cout << endl;
  };

};

#endif
