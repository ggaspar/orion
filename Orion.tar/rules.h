#include "tabel.h"



class Rules
{
  public :
	Rules(int nplayers) : _nplayers(nplayers)//, _tabel(tabel)
	{
	
	};
	int _nplayers;
	//Tabel* _tabel;
	int isStateValid(const Tabel& tabel, const Player& player, const Card& playedCard)
	{
		bool isNotValid = false;
		if(!rValidSuit((const CardSuit&)(tabel._masterSuit), player.getCards(), playedCard))
		{
			return SUIT_NOT_FOLLOWING_MASTER;
		}
		return VALID_MOVE;
	};
	bool rValidSuit(const CardSuit& masterCardSuit, const CardSet& cards, const Card& playedCard) const
	{
		return masterCardSuit==NULL ||  masterCardSuit==playedCard._suit || !cards.hasSuit(masterCardSuit); 
	};


	//two bellow methods could be one template method
	//bug: doesn't recognize draws
	//quick solution, only working with 2 players
	#define PLAYER1 0
	#define PLAYER2 1
	#define CARD1 (*tabel->_players[PLAYER1]->_card)
	#define CARD2 (*tabel->_players[PLAYER2]->_card)
	PlayerId getRoundWinner(const Tabel* tabel) const
	{		
		if(CARD1._suit==tabel->_masterSuit && CARD1 > CARD2)
			return PLAYER1;
		else return PLAYER2;
/*
		Card* highestCard = tabel->_players[0]->_card;
		PlayerId highestPlayerId=0;


		for(int pIndex = 0;	pIndex < tabel->_players.size(); ++pIndex)
		{
			
			if((*highestCard) < (*tabel->_players[pIndex]->_card))
			{
				highestPlayerId = tabel->_players[pIndex]->_playerId;
				highestCard = tabel->_players[pIndex]->_card;
			}
		}
		return highestPlayerId;*/
	};

	PlayerId getGameWinner(const Tabel* tabel) const
	{
		int topPoints = 0;
		PlayerId highestPlayerId = -1;
		for(int pIndex = 0;	pIndex < tabel->_players.size(); ++pIndex)
		{
			if(topPoints < tabel->_players[pIndex]->_points)
			{
				highestPlayerId = tabel->_players[pIndex]->_playerId;
				topPoints = tabel->_players[pIndex]->_points;
			}
		}
		return highestPlayerId;
	}


};

