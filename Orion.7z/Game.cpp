#include "Game.h"
#include "UserInterface.h"


void Game::createPlayers()
{
	Player* player = new PlayerHuman("Human");
	PlayerId id = _gameBoard->addPlayer(player);
	_players[id] = player->getName();
	player = new PlayerDerp("Derp");
	id = _gameBoard->addPlayer(player);
	_players[id] = player->getName();
	return;
}
void Game::createGameBoard()
{
	_gameBoard = new GameBoard;
}

void Game::playGame()
{
	_gameBoard->startGame();			
}

