#include "playerDerp.h"
#include "playerHuman.h"
#include "GameBoard.h"
#include "rules.h"
#include <map>

#ifndef __GAME_H__
#define __GAME_H__

class Game
{
 public :
	 
	Game() : _gameBoard(0)
	{
		createGameBoard();
		createPlayers();
	};

	void createPlayers();

	void createGameBoard();
	
	void announceWinner();

	void playGame();

 private :	
	map<PlayerId,string> _players;
	CardSet* _cards;
	Rules* _rules;
	GameBoard* _gameBoard;
};
#endif