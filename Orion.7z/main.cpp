#include "game.h"
#include <iostream>
#include <string>

using namespace std;


int main()
{
 char eog;
 Game game; 
 game.playGame();
 
 cin >> eog;
 return 0;
}

