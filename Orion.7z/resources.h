
#ifndef __RESOURCES_H__
#define __RESOURCES_H__

#define SUIT_NOT_FOLLOWING_MASTER 1
#define CARD_NOT_RECOGNIZED 2
#define FIRST_MOVE 0
#define VALID_MOVE 0
#define PlayerId int

#endif
